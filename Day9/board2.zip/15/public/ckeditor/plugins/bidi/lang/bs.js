﻿CKEDITOR.plugins.setLang("bidi","bs",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});
