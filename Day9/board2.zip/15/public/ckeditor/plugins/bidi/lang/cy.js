﻿CKEDITOR.plugins.setLang("bidi","cy",{ltr:"Cyfeiriad testun o'r chwith i'r dde",rtl:"Cyfeiriad testun o'r dde i'r chwith"});
