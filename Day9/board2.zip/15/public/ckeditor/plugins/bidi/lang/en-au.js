﻿CKEDITOR.plugins.setLang("bidi","en-au",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});
