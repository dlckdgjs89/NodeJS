﻿CKEDITOR.plugins.setLang("bidi","et",{ltr:"Teksti suund vasakult paremale",rtl:"Teksti suund paremalt vasakule"});
