﻿CKEDITOR.plugins.setLang("bidi","fi",{ltr:"Tekstin suunta vasemmalta oikealle",rtl:"Tekstin suunta oikealta vasemmalle"});
