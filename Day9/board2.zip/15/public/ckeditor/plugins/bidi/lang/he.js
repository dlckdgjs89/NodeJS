﻿CKEDITOR.plugins.setLang("bidi","he",{ltr:"כיוון טקסט משמאל לימין (LTR)",rtl:"כיוון טקסט מימין לשמאל (RTL)"});
