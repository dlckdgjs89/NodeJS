﻿CKEDITOR.plugins.setLang("bidi","hr",{ltr:"Smjer teksta s lijeva na desno",rtl:"Smjer teksta s desna na lijevo"});
