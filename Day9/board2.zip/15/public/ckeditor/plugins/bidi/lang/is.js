﻿CKEDITOR.plugins.setLang("bidi","is",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});
