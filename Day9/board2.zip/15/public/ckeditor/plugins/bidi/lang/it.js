﻿CKEDITOR.plugins.setLang("bidi","it",{ltr:"Direzione del testo da sinistra verso destra",rtl:"Direzione del testo da destra verso sinistra"});
