﻿CKEDITOR.plugins.setLang("bidi","no",{ltr:"Tekstretning fra venstre til høyre",rtl:"Tekstretning fra høyre til venstre"});
