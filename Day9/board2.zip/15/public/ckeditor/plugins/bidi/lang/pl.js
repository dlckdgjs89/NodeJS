﻿CKEDITOR.plugins.setLang("bidi","pl",{ltr:"Kierunek tekstu od lewej strony do prawej",rtl:"Kierunek tekstu od prawej strony do lewej"});
