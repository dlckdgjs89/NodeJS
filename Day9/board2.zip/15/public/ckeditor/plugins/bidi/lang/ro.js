﻿CKEDITOR.plugins.setLang("bidi","ro",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});
