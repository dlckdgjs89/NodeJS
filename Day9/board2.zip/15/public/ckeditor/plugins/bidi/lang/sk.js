﻿CKEDITOR.plugins.setLang("bidi","sk",{ltr:"Smer textu zľava doprava",rtl:"Smer textu sprava doľava"});
