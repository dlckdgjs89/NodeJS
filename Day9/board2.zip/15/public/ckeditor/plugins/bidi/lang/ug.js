﻿CKEDITOR.plugins.setLang("bidi","ug",{ltr:"تېكىست يۆنىلىشى سولدىن ئوڭغا",rtl:"تېكىست يۆنىلىشى ئوڭدىن سولغا"});
