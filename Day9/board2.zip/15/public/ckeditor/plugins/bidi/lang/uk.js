﻿CKEDITOR.plugins.setLang("bidi","uk",{ltr:"Напрямок тексту зліва направо",rtl:"Напрямок тексту справа наліво"});
