﻿CKEDITOR.plugins.setLang("bidi","vi",{ltr:"Văn bản hướng từ trái sang phải",rtl:"Văn bản hướng từ phải sang trái"});
