﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","da",{button:"Indsæt koden her",codeContents:"Code content",emptySnippetError:"A code snippet cannot be empty.",language:"Sprog",title:"Kodestykke",pathName:"kodestykke"});
