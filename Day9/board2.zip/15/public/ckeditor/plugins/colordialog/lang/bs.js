﻿CKEDITOR.plugins.setLang("colordialog","bs",{clear:"Clear",highlight:"Highlight",options:"Color Options",selected:"Selected Color",title:"Select color"});
