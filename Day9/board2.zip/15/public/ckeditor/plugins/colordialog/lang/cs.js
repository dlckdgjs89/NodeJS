﻿CKEDITOR.plugins.setLang("colordialog","cs",{clear:"Vyčistit",highlight:"Zvýraznit",options:"Nastavení barvy",selected:"Vybráno",title:"Výběr barvy"});
