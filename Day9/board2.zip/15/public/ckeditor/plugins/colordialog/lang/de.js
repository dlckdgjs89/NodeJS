﻿CKEDITOR.plugins.setLang("colordialog","de",{clear:"Entfernen",highlight:"Hervorheben",options:"Farbeoptionen",selected:"Ausgewählte Farbe",title:"Farbe wählen"});
