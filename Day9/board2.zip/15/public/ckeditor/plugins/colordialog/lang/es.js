﻿CKEDITOR.plugins.setLang("colordialog","es",{clear:"Borrar",highlight:"Muestra",options:"Opciones de colores",selected:"Elegido",title:"Elegir color"});
