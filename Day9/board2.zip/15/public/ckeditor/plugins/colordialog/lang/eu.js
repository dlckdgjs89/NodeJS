﻿CKEDITOR.plugins.setLang("colordialog","eu",{clear:"Garbitu",highlight:"Nabarmendu",options:"Kolore Aukerak",selected:"Hautatutako Kolorea",title:"Kolorea Hautatu"});
