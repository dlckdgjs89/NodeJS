﻿CKEDITOR.plugins.setLang("colordialog","fo",{clear:"Strika",highlight:"Framheva",options:"Litmøguleikar",selected:"Valdur litur",title:"Vel lit"});
