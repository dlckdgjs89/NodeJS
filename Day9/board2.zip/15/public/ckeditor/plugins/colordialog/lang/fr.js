﻿CKEDITOR.plugins.setLang("colordialog","fr",{clear:"Effacer",highlight:"Détails",options:"Option des couleurs",selected:"Couleur choisie",title:"Choisir une couleur"});
