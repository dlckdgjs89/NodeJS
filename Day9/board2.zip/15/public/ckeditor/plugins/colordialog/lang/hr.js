﻿CKEDITOR.plugins.setLang("colordialog","hr",{clear:"Očisti",highlight:"Istaknuto",options:"Opcije boje",selected:"Odabrana boja",title:"Odaberi boju"});
