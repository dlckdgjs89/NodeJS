﻿CKEDITOR.plugins.setLang("colordialog","ka",{clear:"გასუფთავება",highlight:"ჩვენება",options:"ფერის პარამეტრები",selected:"არჩეული ფერი",title:"ფერის შეცვლა"});
