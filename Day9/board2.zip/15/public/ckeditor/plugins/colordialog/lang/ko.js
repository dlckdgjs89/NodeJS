﻿CKEDITOR.plugins.setLang("colordialog","ko",{clear:"제거",highlight:"하이라이트",options:"색상 옵션",selected:"색상 선택됨",title:"색상 선택"});
