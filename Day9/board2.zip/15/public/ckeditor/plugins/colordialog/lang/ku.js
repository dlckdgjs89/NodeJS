﻿CKEDITOR.plugins.setLang("colordialog","ku",{clear:"پاکیکەوە",highlight:"نیشانکردن",options:"هەڵبژاردەی ڕەنگەکان",selected:"ڕەنگی هەڵبژێردراو",title:"هەڵبژاردنی ڕەنگ"});
