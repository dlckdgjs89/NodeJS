﻿CKEDITOR.plugins.setLang("colordialog","mk",{clear:"Clear",highlight:"Highlight",options:"Color Options",selected:"Selected Color",title:"Select color"});
