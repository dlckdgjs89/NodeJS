﻿CKEDITOR.plugins.setLang("colordialog","nb",{clear:"Tøm",highlight:"Merk",options:"Alternativer for farge",selected:"Valgt",title:"Velg farge"});
