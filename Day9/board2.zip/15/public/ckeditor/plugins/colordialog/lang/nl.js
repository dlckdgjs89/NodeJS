﻿CKEDITOR.plugins.setLang("colordialog","nl",{clear:"Wissen",highlight:"Actief",options:"Kleuropties",selected:"Geselecteerde kleur",title:"Selecteer kleur"});
