﻿CKEDITOR.plugins.setLang("colordialog","no",{clear:"Tøm",highlight:"Merk",options:"Alternativer for farge",selected:"Valgt",title:"Velg farge"});
