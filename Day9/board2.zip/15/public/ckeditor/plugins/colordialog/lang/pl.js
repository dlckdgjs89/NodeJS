﻿CKEDITOR.plugins.setLang("colordialog","pl",{clear:"Wyczyść",highlight:"Zaznacz",options:"Opcje koloru",selected:"Wybrany",title:"Wybierz kolor"});
