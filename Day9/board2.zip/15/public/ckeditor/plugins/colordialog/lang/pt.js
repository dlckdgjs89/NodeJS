﻿CKEDITOR.plugins.setLang("colordialog","pt",{clear:"Limpar",highlight:"Realçar",options:"Opções de cor",selected:"Cor selecionada",title:"Selecionar cor"});
