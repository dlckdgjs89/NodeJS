﻿CKEDITOR.plugins.setLang("colordialog","sl",{clear:"Počisti",highlight:"Poudarjeno",options:"Barvne Možnosti",selected:"Izbrano",title:"Izberi barvo"});
