﻿CKEDITOR.plugins.setLang("colordialog","sq",{clear:"Pastro",highlight:"Thekso",options:"Përzgjedhjet e Ngjyrave",selected:"Ngjyra e Përzgjedhur",title:"Përzgjidh një ngjyrë"});
