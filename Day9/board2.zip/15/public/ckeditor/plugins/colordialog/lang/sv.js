﻿CKEDITOR.plugins.setLang("colordialog","sv",{clear:"Rensa",highlight:"Markera",options:"Färgalternativ",selected:"Vald färg",title:"Välj färg"});
