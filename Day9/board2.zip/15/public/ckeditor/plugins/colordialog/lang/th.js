﻿CKEDITOR.plugins.setLang("colordialog","th",{clear:"Clear",highlight:"Highlight",options:"Color Options",selected:"Selected Color",title:"Select color"});
