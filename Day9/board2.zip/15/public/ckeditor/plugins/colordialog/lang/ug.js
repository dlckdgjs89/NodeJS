﻿CKEDITOR.plugins.setLang("colordialog","ug",{clear:"تازىلا",highlight:"يورۇت",options:"رەڭ تاللانمىسى",selected:"رەڭ تاللاڭ",title:"رەڭ تاللاڭ"});
