﻿CKEDITOR.plugins.setLang("colordialog","vi",{clear:"Xóa bỏ",highlight:"Màu chọn",options:"Tùy chọn màu",selected:"Màu đã chọn",title:"Chọn màu"});
